import json
import Pedra
import random

#Monte Carlo Tree Search Player
class MCTSPlayer:
	
	mao = None
	mesa = []
	monte = []
	edgeA = None
	edgeB = None
	opponent_hand_amount = None
	is_first = False
	# pedra_most_valorosa = None


	def __init__(self,mao):
		self.mao = mao
		# self.opponent_hand_amount = opponent_hand_amount
		self.game_pedras = [Pedra.Pedra(0,0), Pedra.Pedra(0,1), Pedra.Pedra(0,2), Pedra.Pedra(0,3), Pedra.Pedra(0,4), Pedra.Pedra(0,5),
		Pedra.Pedra(0,6), Pedra.Pedra(1,1), Pedra.Pedra(1,2), Pedra.Pedra(1,3), Pedra.Pedra(1,4), Pedra.Pedra(1,5), Pedra.Pedra(1,6),
		Pedra.Pedra(2,2), Pedra.Pedra(2,3), Pedra.Pedra(2,4), Pedra.Pedra(2,5), Pedra.Pedra(2,6), Pedra.Pedra(3,3), Pedra.Pedra(3,4),
		Pedra.Pedra(3,5), Pedra.Pedra(3,6), Pedra.Pedra(4,4), Pedra.Pedra(4,5), Pedra.Pedra(4,6), Pedra.Pedra(5,5), Pedra.Pedra(5,6),
		Pedra.Pedra(6,6)]

		# self.pedra_most_valorosa = mao.pedra_most_valorosa
		return

	def __str__(self):
		response = "\nThe current Hand for the MCTSPlayer is \n"
		for i in self.mao.pedras:
			response += str(i) + " "
		response += "\n"
		return response
	
	def set_which_turn(self,which_turn):
		self.is_first = which_turn
		return

	def play_turno(self,mesa,monte,opponent_hand_amount):
		self.mesa = mesa
		self.monte = monte
		self.edgeA = mesa[0] 
		self.edgeB = mesa[len(mesa)-1]
		self.opponent_hand_amount = opponent_hand_amount
		response = self.select()

		return response 

	def select(self):
		# Inicia a árvore a partir do estado de jogo inicial, usando como root o nó da primeira jogada possivel
		# Loop sobre as pedras na mão 
		array = []
		buy = True
		for pedra in self.mao.pedras:

			if(pedra.ladoA == self.edgeA.edge or pedra.ladoB == self.edgeA.edge): # Checa se é possivel fazer a jogada
	
				if(pedra.ladoA == self.edgeA.edge): 
					pedra.set_edge(pedra.ladoB) # Seta qual a extremidade da pedra que ficará exposta 
					self.test_node(pedra,array)
				
				if(pedra.ladoB == self.edgeA.edge): 
					pedra.set_edge(pedra.ladoA) # Seta qual a extremidade da pedra que ficará exposta 
					self.test_node(pedra,array)
				
				buy = False

			if(pedra.ladoA == self.edgeB.edge or pedra.ladoB == self.edgeB.edge): # Checa se é possivel fazer a jogada
				if(pedra.ladoA == self.edgeB.edge): 
					pedra.set_edge(pedra.ladoB) # Seta qual a extremidade da pedra que ficará exposta 
					self.test_node(pedra,array)

				
				if(pedra.ladoB == self.edgeB.edge): 
					pedra.set_edge(pedra.ladoA) # Seta qual a extremidade da pedra que ficará exposta 
					self.test_node(pedra,array)

				buy = False

		if(buy == False):
			print("Pedras in array")
			for pedra in array:
				print(pedra,end=" ")
			if (len(array) != 0):
				no = self.best_choice(array)
				no.count_wins()
				for x in range(len(no.children)):
					print("this sub child have ", len(no.children[x].children))

				for x in range(len(no.children)):
					for y in range(len(no.children[x].children)):
						print("this = ",len(no.children[x].children[y].children))
				self.update_play(no)
				response = [self.mesa,self.mao]
				return response

		else:
			self.buy()
		
	def test_node(self,pedra,array):
		node = Node() # Cria o Node ROOT do MCTS
		node.set_opponent_amount(self.opponent_hand_amount)
		node.set_mesa(self.mesa.copy())
		node.set_pedra(pedra)
		node.set_mao_state(self.mao.pedras.copy()	)
		node.set_game_pedras(self.game_pedras.copy())
		node.increase_profundidade(1)
		node.play()
		array.append(node)
		return
						
	
	def best_choice(self,array_nodes):
		current_node = array_nodes[0]
		for node in array_nodes:
			print("node status")
			print(node.wins)
			print(node.deaths)
			print(node.empates)
			print()
			if(current_node.wins < node.wins):
				current_node = node
		return current_node

	def update_play(self,no):
		print("update")
		if(no.pedra.ladoA == self.edgeA.edge or no.pedra.ladoB == self.edgeA.edge):
			self.mesa.insert(0,no.pedra) # Insere na mesa a pedra na posiçao referente à jogada
		elif(no.pedra.ladoA == self.edgeB.edge or no.pedra.ladoB == self.edgeB.edge):
			self.mesa.append(no.pedra) # Insere na mesa a pedra na posiçao referente à jogada
		self.mao.pedras.remove(no.pedra)
		return

	def buy(self):
		self.mao.pedras.append(self.monte[0])
		self.monte.remove(self.monte[0])
		response = [self.mesa,self.monte]
		return response
		


# Node 
class Node:

	# Class node da MCTS

	# Parent será usado para definir se o Nó tem um Pai, e se ele é o opponent ou eu

	pedra = None
	game_pedras = []
	mao_state = []
	mesa_state = []
	opponent_hand_plus_mount = []
	opponent_hand_amount = None
	opponent = []
	parent = ""
	won = ""
	edgeA = None
	edgeB = None
	profundidade = 0
	opponent_setted = False

	# "construtor" da classe nó
	def __init__(self,parent="",won=""):
		self.won = won
		self.parent = parent
		self.children = []
		self.wins = 0
		self.deaths = 0
		self.empates = 0
		return

	def play(self):
		# Checa se venceu, empatou ou perdeu
		if(len(self.game_pedras) == 0):
			if(len(self.mao_state) == self.opponent_hand_amount):
				self.empates += 1
			elif (len(self.mao_state) < self.opponent_hand_amount):
				self.wins += 1
			else:
				self.deaths += 1
			return
		print()
		print("Deu play")
		print()

		if(self.is_vencedor(self.mao_state)):
			if(self.won == False):
				self.wins += 1
			else:
				self.empates += 1
			return

		elif(not(self.is_vencedor(self.mao_state))):
			if(self.won == True):
				self.deaths += 1
			elif (self.profundidade == 10):
				print("END OF TREE")
				if(len(self.mao_state) == self.opponent_hand_amount):
					self.empates = self.empates + 1
					print("empates = ",self.empates)
				elif (len(self.mao_state) < self.opponent_hand_amount):
					self.wins = self.wins + 1
					print("wins = ",self.wins)
				else:
					self.deaths = self.deaths + 1
					print("deaths = ",self.deaths)
				return 

			# Caso nao esteja no final ( não seja folha )
			self.edgeA = self.mesa_state[0] # define as pontas da mesa
			self.edgeB = self.mesa_state[len(self.mesa_state)-1] # define as pontas da mesa

			if(self.parent != "opponent"): # Se o parent foi jogado por mim

				self.opponent_hand_plus_mount = self.get_resto() # atribui o conteudo de opponent hand plus mount da função get_resto()
				self.expand() # expand o nó baseado no parent "me"

			else:
				buy = True
				for pedra in self.mao_state:
					if(pedra.ladoA == self.edgeA.edge or pedra.ladoB == self.edgeA.edge):
						if(pedra.ladoA == self.edgeA.edge):
							buy = False
							pedra.set_edge(pedra.ladoB)
							self.mesa_state.insert(0,pedra)
							self.mao_state.remove(pedra)
							self.mcts_play(pedra)
							self.mesa_state.pop(0)
							self.mao_state.append(pedra)
							return

						if(pedra.ladoB == self.edgeA.edge):
							if(not(pedra.is_simetrico())):
								buy = False
								pedra.set_edge(pedra.ladoA)
								self.mesa_state.insert(0,pedra)
								self.mao_state.remove(pedra)
								self.mcts_play(pedra)
								self.mesa_state.pop(0)
								self.mao_state.append(pedra)
								return
		return

	def mcts_play(self,pedra):
		node = Node()
		node.set_pedra(pedra)
		node.set_mesa(self.mesa_state.copy())
		node.set_mao_state(self.mao_state.copy())
		node.set_game_pedras(self.game_pedras.copy())
		node.set_opponent_amount(self.opponent_hand_amount)
		node.set_parent("me")
		node.increase_profundidade(self.profundidade+1)
		node.play()
		self.add_children(node)
		print("children added me = profundidade = ",self.profundidade)
		print("wins =",self.children[0].wins)
		print("death =",self.children[0].deaths)
		print("empates =",self.children[0].empates)
		for x in self.children:
			print("wins =", x.wins)
			self.wins = self.wins + x.wins
			print("deaths = ",x.deaths)
			self.deaths = self.deaths + x.deaths
			print("empates = ",x.empates)
			self.empates = self.empates + x.empates
		
		print("my wins propagation", self.wins)
		print("my deaths propagation", self.deaths)
		print("my empates propagation", self.empates)
		#node.count_wins()
		return

	
	def increase_profundidade(self,profundidade):
		self.profundidade = profundidade
		return

	def set_won(self,won):
		self.won = won
		return

	def set_parent(self,parent):
		self.parent = parent
		return

	def set_opponent(self,opponent):
		self.opponent = opponent
		print("opponent =",self.opponent)
		return

	def set_opponent_amount(self,opponent_hand_amount):
		self.opponent_hand_amount = opponent_hand_amount
		return
	def set_mesa(self,mesa_state):
		self.mesa_state = mesa_state
		return

	def set_game_pedras(self,game_pedras):
		self.game_pedras = game_pedras
		return

	def set_pedra(self,pedra):
		self.pedra = pedra
		return

	def set_mao_state(self,mao_state):
		self.mao_state = mao_state
		return

	def add_children(self,child_state):
		self.children.append(child_state)
		return

	def sort_opponent(self):
		random.shuffle(self.game_pedras)
		self.opponent = self.game_pedras[:self.opponent_hand_amount]
		return

	def set_opponent(self,opponent):
		self.opponent = opponent
		return

	def opponent_set(self):
		self.opponent_setted = True
		return

	def get_resto(self):
		for p in range(len(self.mao_state)):
			for o in range(len(self.game_pedras)):
				if(self.mao_state[p-1].is_igual(self.game_pedras[o-1])):
					self.game_pedras.pop(p-1)
		return self.game_pedras

	def expand(self):
		print("expand")
		#print(self.opponent_setted)
		if(self.opponent_setted == False):
			for x in range(10):
				self.sort_opponent()
				for p in self.opponent: # loop sobre as pedras no opponent hand plus mount
					buy = True
					if(p.ladoA == self.edgeA.edge or p.ladoB == self.edgeA.edge): # checa se é possivel fazer a jogada com aquela pedra
						self.mesa_state.insert(0,p) # insere a pedra na mesa
						self.opponent_hand_amount -= 1 # retira 1 do valor mão do oponente
						self.opponent.remove(p) # remove a pedra do game_pedras

						if(self.opponent_hand_amount == 0): # se a mão do oponente é = 0, inicia o próximo nó com a tag Won = True
							self.opponent_play(True,p)

						else: # else inicia sem a tag Won
							self.opponent_play(False,p)


						self.mesa_state.pop(0) # insere a pedra na mesa
						self.opponent_hand_amount += 1 # retira 1 do valor mão do oponente
						self.opponent.append(p) # remove a pedra do game_pedras

						buy = False


					if(p.ladoA == self.edgeB.edge or p.ladoB == self.edgeB.edge): # checa se é possivel fazer a jogada com aquela pedra
						self.mesa_state.append(p) # insere a pedra na mesa
						self.opponent_hand_amount -= 1 # retira 1 do valor mão do oponente
						self.opponent.remove(p) # remove a pedra do game_pedras
						if(self.opponent_hand_amount == 0): # se a mão do oponente é = 0, inicia o próximo nó com a tag Won = True
							self.opponent_play(True,p)

						else: # else inicia sem a tag Won
							self.opponent_play(False,p)

						self.mesa_state.remove(p) # insere a pedra na mesa
						self.opponent_hand_amount += 1 # retira 1 do valor mão do oponente
						self.opponent.append(p) # remove a pedra do game_pedras

						buy = False			

					if(buy == True):
						self.buy()
						return

		else:
				for p in self.opponent: # loop sobre as pedras no opponent hand plus mount
					buy = True
					if(p.ladoA == self.edgeA.edge or p.ladoB == self.edgeA.edge): # checa se é possivel fazer a jogada com aquela pedra
						self.mesa_state.insert(0,p) # insere a pedra na mesa
						self.opponent_hand_amount -= 1 # retira 1 do valor mão do oponente
						self.opponent.remove(p) # remove a pedra do game_pedras
						if(self.opponent_hand_amount == 0): # se a mão do oponente é = 0, inicia o próximo nó com a tag Won = True
							self.opponent_remove(p)
							self.opponent_play(True,p)
							self.opponent.append(p)

						else: # else inicia sem a tag Won
							self.opponent.remove(p)
							self.opponent_play(False,p)
							self.opponent.append(p)


						self.mesa_state.pop(0) # insere a pedra na mesa
						self.opponent_hand_amount += 1 # retira 1 do valor mão do oponente
						self.opponent.append(p) # remove a pedra do game_pedras
						buy = False

						print("Node wins deaths empates PROFUNDIDADE = ", self.profundidade)
						print("childrens = ", self.children)

					if(p.ladoA == self.edgeB.edge or p.ladoB == self.edgeB.edge): # checa se é possivel fazer a jogada com aquela pedra
						self.mesa_state.append(p) # insere a pedra na mesa
						self.opponent_hand_amount -= 1 # retira 1 do valor mão do oponente
						self.opponent.remove(p) # remove a pedra do game_pedras
						if(self.opponent_hand_amount == 0): # se a mão do oponente é = 0, inicia o próximo nó com a tag Won = True
							self.opponent.remove(p)
							self.opponent_play(True,p)
							self.opponent.append(p)

						else: # else inicia sem a tag Won
							self.opponent.remove(p)
							self.opponent_play(False,p)
							self.opponent.append(p)

						self.mesa_state.remove(0) # insere a pedra na mesa
						self.opponent_hand_amount += 1 # retira 1 do valor mão do oponente
						self.opponent.append(p) # remove a pedra do game_pedras

						buy = False

						print("Node wins deaths empates PROFUNDIDADE = ", profundidade)

					if (buy == True):
						self.buy()
						return

	def opponent_play(self,won,p):
		child = Node()
		child.set_mesa(self.mesa_state.copy())
		child.set_pedra(p)
		child.set_mao_state(self.mao_state.copy())
		child.set_game_pedras(self.game_pedras.copy())
		child.set_opponent_amount(self.opponent_hand_amount)
		child.set_opponent(self.opponent.copy())
		child.set_parent("opponent")
		child.opponent_set()
		if(won == True):
			child.set_won(True)
		child.increase_profundidade(self.profundidade+1)
		child.play()
		self.add_children(child)
		print("children added me = profundidade = ",self.profundidade)
		print("wins =",self.children[0].wins)
		print("death =",self.children[0].deaths)
		print("empates =",self.children[0].empates)
		for x in self.children:
			print("wins =",x.wins)
			self.wins += x.wins
			print("deaths = ",x.deaths)
			self.deaths += x.deaths
			print("empates = ",x.empates)
			self.empates += x.empates

		print("my wins propagation", self.wins)
		print("my deaths propagation", self.deaths)
		print("my empates propagation", self.empates)
		#child.count_wins() # Conta os wins, deaths, draws
		return

	def buy(self):
		if(len(self.game_pedras) != 1):
			self.opponent.append(self.game_pedras[0])
			self.game_pedras.remove(self.game_pedras[0])
			self.opponent_hand_amount += 1

			child = Node()
			child.set_mesa(self.mesa_state.copy())
			child.set_mao_state(self.mao_state.copy())
			child.set_game_pedras(self.game_pedras.copy())
			child.set_opponent_amount(self.opponent_hand_amount)
			child.set_opponent(self.opponent.copy())
			child.opponent_set()
			child.set_parent("opponent")
			child.increase_profundidade(self.profundidade+1)
			child.play()
			self.add_children(child)
			print("children added me = profundidade = ",self.profundidade)
			print("wins =",self.children[0].wins)
			print("death =",self.children[0].deaths)
			print("empates =",self.children[0].empates)
			for x in self.children:
				print("wins =",x.wins)
				self.wins += x.wins
				print("deaths = ",x.deaths)
				self.deaths += x.deaths
				print("empates = ",x.empates)
				self.empates += x.empates

			print("my wins propagation", self.wins)
			print("my deaths propagation", self.deaths)
			print("my empates propagation", self.empates)
								
			self.opponent.remove(self.game_pedras[0])
			self.game_pedras.append(self.game_pedras[0])
			self.opponent_hand_amount -= 1
		self.check_win()

		return
	def check_win(self):
		if(len(self.mao_state) == self.opponent_hand_amount):
			self.empates = self.empates + 1
			print("empates = ",self.empates)
		elif (len(self.mao_state) < self.opponent_hand_amount):
			self.wins = self.wins + 1
			print("wins = ",self.wins)
		else:
			self.deaths = self.deaths + 1
			print("deaths = ",self.deaths)		
		return

	# Checa se o length da mão é = 0 || vencedor ou não
	def is_vencedor(self,mao):
		if(len(mao)==0):
			return True
		else:
			return False

	# Conta os valores de wins deaths e empates
	def count_wins(self):
#		print("nodes in children :",len(self.children))
		for nodes in self.children:
			self.wins += nodes.wins
			self.deaths += nodes.deaths
			self.empates += nodes.empates
