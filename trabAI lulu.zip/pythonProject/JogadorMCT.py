class JogadorMCT:
	#atributos: mao 
	#metodos buy_pedra, play_turno
