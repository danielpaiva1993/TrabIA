import Pedra
import Mao
import random
import mcts_player2

class Domino:

	# Monte Carlo Tree Search Player
	mcts_jogador = None
	maoA = []

	# ExpectMiniMax Player
	expct_jogador = None
	maoB = []


	# Game variables
	pedras = []
	mesa = []
	compra = []

	def __init__(self):

		self.pedras = [Pedra.Pedra(0,0), Pedra.Pedra(0,1), Pedra.Pedra(0,2), Pedra.Pedra(0,3), Pedra.Pedra(0,4), Pedra.Pedra(0,5),
		Pedra.Pedra(0,6), Pedra.Pedra(1,1), Pedra.Pedra(1,2), Pedra.Pedra(1,3), Pedra.Pedra(1,4), Pedra.Pedra(1,5), Pedra.Pedra(1,6),
		Pedra.Pedra(2,2), Pedra.Pedra(2,3), Pedra.Pedra(2,4), Pedra.Pedra(2,5), Pedra.Pedra(2,6), Pedra.Pedra(3,3), Pedra.Pedra(3,4),
		Pedra.Pedra(3,5), Pedra.Pedra(3,6), Pedra.Pedra(4,4), Pedra.Pedra(4,5), Pedra.Pedra(4,6), Pedra.Pedra(5,5), Pedra.Pedra(5,6),
		Pedra.Pedra(6,6)]

		random.shuffle(self.pedras)

		self.maoA = Mao.Mao(self.pedras[:7])
		self.mcts_jogador = mcts_player2.MCTSPlayer(self.maoA)
		print(self.mcts_jogador)
		
		###self.jogadorA = intA.ExpectMiniMax(self.maoA)
		self.maoB = Mao.Mao(self.pedras[7:14])
		###self.jogadorB = intB.MonteCarlo(self.maoB)

		self.compra = self.pedras[14:]
		
		print(self.maoA)
		print(self.maoA.pedra_most_valorosa)
		print()
		print(self.maoB)
		print(self.maoB.pedra_most_valorosa)		

		if(self.who_comeca(self.maoA,self.maoB) == "maoB"):
			self.mesa.append(self.maoB.pedra_most_valorosa)
			self.maoB.pedras.remove(self.maoB.pedra_most_valorosa)
			print()
			print("mao A")
			print(self.maoA)
			print()
			print("Mesa antes: ")
			for pedras in self.mesa:
				print(pedras,end=" ")
			print()
			print()
			response = self.mcts_jogador.play_turno(self.mesa,self.compra,len(self.maoA.pedras))
			print(response)
			print()
			print("Mesa depois: ")
			for pedras in response[0]:
				print(pedras,end=" ")
			print()
			

		#if(self.who_comeca(self.maoA,self.maoB) == "maoA"):
		#	self.maoA.pedras.remove(self.maoA.pedra_most_valorosa)
		#	self.mesa = [self.maoA.pedra_most_valorosa]
		#	print(self.mesa)
		#	print(self.maoA)
			# self.maoA.remove_pedra(self.maoA.pedra_most_valorosa)
			# self.turno(self.mcts_jogador, self.outroJogador)
		#else:
		#	self.mesa = [self.maoB.pedra_most_valorosa]
		#	self.maoB.pedras.remove(self.maoB.pedra_most_valorosa)
		#	print(self.mesa)
		#	print(self.maoB)
			# self.turno(self.mcts_jogador, self.outroJogador)	
		
	
	#def turno(jogadorA, jogadorB):
		'''
			se a mao de jogadorA esta vazia acabou o jogo
				ver quem ganhou
			se não:
				conseguiu = True
				resp = jogadorA.play_turno(mesa, self.compra.length, jogadorB.mao.length)
				se resp != self.mesa :
					self.mesa = retorno
				se não:
					se self.compra.length !=0:
						jogadorA.buy_pedra(self.compra)
						jogadorA.play_turno(mesa, self.compra.length, jogadorB.mao.length)
					se não:
						conseguiu = False

			proxTurno = self.turno(jogadorB, jogadorA)
			se proxTurno e conseguiu são false acaba o jogo
				 ver quem ganhou

			return conseguiu
		'''

	def who_comeca(self,maoA,maoB):
		response = ""
		if(self.maoA.pedra_most_valorosa.is_simetrico() and (not self.maoB.pedra_most_valorosa.is_simetrico())):
			response = "maoA"
		else:
			if(self.maoB.pedra_most_valorosa.is_simetrico() and (not self.maoA.pedra_most_valorosa.is_simetrico())):
				response = "maoB"
			else:
				if(self.maoB.pedra_most_valorosa.get_soma() > self.maoA.pedra_most_valorosa.get_soma()):
					response = "maoB"
				else:
					response = "maoA"
		return response
