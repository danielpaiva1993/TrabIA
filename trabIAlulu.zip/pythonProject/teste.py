teste = Teste(0)

class Teste:
	children = []
	win = 0
	def __ini__(self,ok):
		if(ok == 3):
			self.win = 1
			return
		else:
			teste = Teste(ok+1)
			self.children.append(teste)