class Pedra:
	ladoA = 0
	ladoB = 0

	def __init__(self,ladoA=0,ladoB=0):
		self.ladoA = ladoA
		self.ladoB = ladoB
		self.edge = ladoA
		return

	def __str__(self):
		response = "||"+ str(self.ladoA) + "|"+ str(self.ladoB) + "||"
		return response

	def get_soma(self):
		soma = self.ladoA + self.ladoB
		return soma
	
	def is_simetrico(self):
		simetrico = (self.ladoA == self.ladoB)
		return simetrico

	def is_carrilhao(self):
		if self.is_simetrico() and self.ladoA == 6:
			return True
		return False

	# Function that returns True if the pedra of comparison is equal
	def is_igual(self,pedraB):
		# Compares both sides
		if(self.ladoA == pedraB.ladoA and self.ladoB == pedraB.ladoB):	
			return True
		else:
			return 

	def set_edge(self,lado):
		self.edge = lado
		return 
