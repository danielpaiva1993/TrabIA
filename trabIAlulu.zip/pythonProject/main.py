import Domino as domino
import Mao
import Pedra
# import mcts_player

dom = domino.Domino()