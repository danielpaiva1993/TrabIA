import Pedra
import Mao
import random
import mcts_player2
import jogador_teste

class Domino:

	# Monte Carlo Tree Search Player
	mcts_jogador = None
	maoA = []

	# ExpectMiniMax Player
	expct_jogador = None
	maoB = []


	# Game variables
	pedras = []
	mesa = []
	compra = []

	def __init__(self):

		self.pedras = [Pedra.Pedra(0,0), Pedra.Pedra(0,1), Pedra.Pedra(0,2), Pedra.Pedra(0,3), Pedra.Pedra(0,4), Pedra.Pedra(0,5),
		Pedra.Pedra(0,6), Pedra.Pedra(1,1), Pedra.Pedra(1,2), Pedra.Pedra(1,3), Pedra.Pedra(1,4), Pedra.Pedra(1,5), Pedra.Pedra(1,6),
		Pedra.Pedra(2,2), Pedra.Pedra(2,3), Pedra.Pedra(2,4), Pedra.Pedra(2,5), Pedra.Pedra(2,6), Pedra.Pedra(3,3), Pedra.Pedra(3,4),
		Pedra.Pedra(3,5), Pedra.Pedra(3,6), Pedra.Pedra(4,4), Pedra.Pedra(4,5), Pedra.Pedra(4,6), Pedra.Pedra(5,5), Pedra.Pedra(5,6),
		Pedra.Pedra(6,6)]

		random.shuffle(self.pedras)

		self.maoA = Mao.Mao(self.pedras[:7])
		self.mcts_jogador = mcts_player2.MCTSPlayer(self.maoA)
		self.maoA.nome = "MCTSPlayer"
		#print(self.mcts_jogador)
		
		self.maoB = Mao.Mao(self.pedras[7:14])
		self.expct_jogador = jogador_teste.Jogador_teste(self.maoB)
		self.maoB.nome = "Jogador teste"
		#print(self.expct_jogador)

		self.compra = self.pedras[14:]
		
		#print(self.maoA)
		#print(self.maoA.pedra_most_valorosa)
		#print()
		#print(self.maoB)
		#print(self.maoB.pedra_most_valorosa)		

		# if(self.who_comeca(self.maoA,self.maoB) == "maoB"):
		# 	self.mesa.append(self.maoB.pedra_most_valorosa)
		# 	self.maoB.pedras.remove(self.maoB.pedra_most_valorosa)
		# 	print()
		# 	print("mao A")
		# 	print(self.maoA)
		# 	print()
		# 	print("Monte antes")
		# 	for pedras in self.compra:
		# 		print(pedras,end=" ")
		# 	print()
		# 	print("Mesa antes: ")
		# 	for pedras in self.mesa:
		# 		print(pedras,end=" ")
		# 	print()
		# 	print()
		# 	response = self.mcts_jogador.play_turno(self.mesa,self.compra,len(self.maoA.pedras))
		# 	print(response)
		# 	print()
		# 	print("Monte depois")
		# 	for pedras in response[1]:
		# 		print(pedras,end=" ")
		# 	print()
		# 	print("Mesa depois: ")
		# 	for pedras in response[0]:
		# 		print(pedras,end=" ")
		# 	print()
			

		if(self.who_comeca(self.maoA,self.maoB) == "maoA"):
			self.maoA.pedras.remove(self.maoA.pedra_most_valorosa)
			self.mcts_jogador.mao = self.maoA
			self.mesa = [self.maoA.pedra_most_valorosa]
			print("Mesa inicial")
			for pedras in self.mesa:
				print(pedras)
			self.maoA.remove_pedra(self.maoA.pedra_most_valorosa)
			self.turno(self.expct_jogador, self.mcts_jogador)
		else:
			self.mesa = [self.maoB.pedra_most_valorosa]
			self.maoB.pedras.remove(self.maoB.pedra_most_valorosa)
			self.expct_jogador.mao = self.maoB
			print("Mesa inicial")
			for pedras in self.mesa:
				print(pedras)
			self.turno(self.mcts_jogador, self.expct_jogador)	
		
	
	def turno(self,jogadorA, jogadorB):

		print()
		print("Vez do jogador .... ")
		print("          ",jogadorA.mao.nome)
		print()

		response = jogadorA.play_turno(self.mesa,self.compra,len(self.maoA.pedras))
		jogadorA.mao = response[2]
		if(len(jogadorA.mao.pedras) == 0):
			if(len(jogadorB.mao.pedras) == 0):
				print("Empate")
				return
			else:
				print("jogador ganhador = ", jogadorA.mao.nome)
		elif (len(jogadorB.mao.pedras) == 0):
			print("jogador ganhador = ",jogadorB.mao.nome)

		else:
			self.mesa = response[0]
			self.monte = response[1]
			self.turno2(jogadorB,jogadorA)
		return

	def turno2(self,jogadorB,jogadorA):

		print()
		print("vez do jogador .... ")
		print("		",jogadorB.mao.nome)
		print()

		response = jogadorB.play_turno(self.mesa,self.compra,len(self.maoB.pedras))
		jogadorB.mao = response[2]
		self.mesa = response[0]
		self.monte = response[1]
		self.turno(jogadorA,jogadorB)
		'''
			se a mao de jogadorA esta vazia acabou o jogo
				ver quem ganhou
			se não:
				conseguiu = True
				resp = jogadorA.play_turno(mesa, self.compra.length, jogadorB.mao.length)
				se resp != self.mesa :
					self.mesa = retorno
				se não:
					se self.compra.length !=0:
						jogadorA.buy_pedra(self.compra)
						jogadorA.play_turno(mesa, self.compra.length, jogadorB.mao.length)
					se não:
						conseguiu = False

			proxTurno = self.turno(jogadorB, jogadorA)
			se proxTurno e conseguiu são false acaba o jogo
				 ver quem ganhou

			return conseguiu
		'''

	def who_comeca(self,maoA,maoB):
		response = ""
		if(self.maoA.pedra_most_valorosa.is_simetrico() and (not self.maoB.pedra_most_valorosa.is_simetrico())):
			response = "maoA"
		else:
			if(self.maoB.pedra_most_valorosa.is_simetrico() and (not self.maoA.pedra_most_valorosa.is_simetrico())):
				response = "maoB"
			else:
				if(self.maoB.pedra_most_valorosa.get_soma() > self.maoA.pedra_most_valorosa.get_soma()):
					response = "maoB"
				else:
					response = "maoA"
		return response
