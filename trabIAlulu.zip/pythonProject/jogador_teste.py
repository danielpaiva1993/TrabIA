import random

class Jogador_teste:

	mao = None
	mesa = []
	monte = []
	edgeA = None
	edgeB =  None

	def __init__(self,mao):
		self.mao = mao

	def __str__(self):
		response = "\nThe current Hand for the jogador teste is \n"
		for i in self.mao.pedras:
			response += str(i) + " "
		response += "\n"
		return response

	def play_turno(self,mesa,monte,mao):
		self.mesa = mesa
		self.monte = monte
		self.edgeA = mesa[0]
		self.edgeB = mesa[len(mesa)-1]
		self.play()
		response = [self.mesa,self.monte,self.mao]
		return response
        

	def play(self):
		array = []
		for pedra in self.mao.pedras:
			if(pedra.ladoA == self.edgeA.edge or pedra.ladoB == self.edgeA.edge or pedra.ladoA == self.edgeB.edge or pedra.ladoB == self.edgeB.edge):
				array.append(pedra)

		print()
		print("Mesa : ")

		for pedras in self.mesa:
			print(pedras,end=" ")
		print()
		print()
		print("Mao: ",self.mao)
		print()
		print("Possibilidades de jogadas: ")

		for pedras in array:
			print(pedras,end=" ")
		print()
		print()

		if(len(array) == 0):
			print("Você nao pode jogar, compre uma peça !")
			inn = input()
			print()
			self.buy()
			return

		userIn = int(input("Digite o numero de 1 a (número de possibildades) para selecionar uma pedra para jogar: "))
		if((array[userIn-1].ladoA == self.edgeA.edge or array[userIn-1].ladoB == self.edgeA.edge) and (array[userIn-1].ladoA == self.edgeB.edge or array[userIn-1].ladoB == self.edgeB.edge)):
			print("Deseja jogar à esquerda ou direita da mesa ?")
			userIn2 = int(input("1 - Esquerda || 2 - Direita"))
			if(userIn2 == 1):
				self.mesa.insert(0,array[userIn-1])
				if(array[userIn-1].ladoA == self.edgeA.edge):
					array[userIn-1].edge = array[userIn-1].ladoB
				elif (array[userIn-1].ladoB == self.edgeA.edge):
					array[userIn-1].edge = array[userIn-1].ladoA

			if(userIn2 == 2):
				self.mesa.append(array[userIn-1])
				if(array[userIn-1].ladoA == self.edgeB.edge):
					array[userIn-1].edge = array[userIn-1].ladoB
				elif (array[userIn-1].ladoB == self.edgeB.edge):
					array[userIn-1].edge = array[userIn-1].ladoA
			print()
			self.mao.pedras.remove(array[userIn-1])
			print("Fim da jogada")
			print()
			print("Mesa agora ficou assim: ")
			for pedras in self.mesa:
				print(pedras,end=" ")
			print()
			print()
			print("edges = ",self.mesa[0].edge, self.mesa[len(self.mesa)-1].edge)

		elif (array[userIn-1].ladoA == self.edgeA.edge or array[userIn-1].ladoB == self.edgeA.edge):
			self.mesa.insert(0,array[userIn-1])
			if(array[userIn-1].ladoA == self.edgeA.edge):
				array[userIn-1].edge = array[userIn-1].ladoB
			elif (array[userIn-1].ladoB == self.edgeA.edge):
				array[userIn-1].edge = array[userIn-1].ladoA
			self.mao.pedras.remove(array[userIn-1])
		
		elif (array[userIn-1].ladoA == self.edgeB.edge or array[userIn-1].ladoB == self.edgeB.edge):
			self.mesa.append(array[userIn-1])
			if(array[userIn-1].ladoA == self.edgeB.edge):
				array[userIn-1].edge = array[userIn-1].ladoB
			elif (array[userIn-1].ladoB == self.edgeB.edge):
				array[userIn-1].edge = array[userIn-1].ladoA
			self.mao.pedras.remove(array[userIn-1])

		print()
		print("Fim da jogada")
		print()
		print("Mesa agora ficou assim: ")
		for pedras in self.mesa:
			print(pedras,end=" ")
		print()
		print()
		print("edges = ",self.mesa[0].edge, self.mesa[len(self.mesa)-1].edge)

	def buy(self):
		print("peça comprada")
		print()
		self.mao.pedras.append(self.monte[0])
		self.monte.remove(self.monte[0])
		return
