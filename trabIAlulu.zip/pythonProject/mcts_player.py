import json
import Pedra

#Monte Carlo 
class MCTSPlayer:

	game_pedras

	mao = None
	mesa = None
	monte = None
	edgeA = None
	edgeB = None
	# pedra_most_valorosa = None


	def __init__(self,mao):
		self.mao = mao
		self.game_pedras = [Pedra.Pedra(0,0), Pedra.Pedra(0,1), Pedra.Pedra(0,2), Pedra.Pedra(0,3), Pedra.Pedra(0,4), Pedra.Pedra(0,5),
		Pedra.Pedra(0,6), Pedra.Pedra(1,1), Pedra.Pedra(1,2), Pedra.Pedra(1,3), Pedra.Pedra(1,4), Pedra.Pedra(1,5), Pedra.Pedra(1,6),
		Pedra.Pedra(2,2), Pedra.Pedra(2,3), Pedra.Pedra(2,4), Pedra.Pedra(2,5), Pedra.Pedra(2,6), Pedra.Pedra(3,3), Pedra.Pedra(3,4),
		Pedra.Pedra(3,5), Pedra.Pedra(3,6), Pedra.Pedra(4,4), Pedra.Pedra(4,5), Pedra.Pedra(4,6), Pedra.Pedra(5,5), Pedra.Pedra(5,6),
		Pedra.Pedra(6,6)]

		# self.pedra_most_valorosa = mao.pedra_most_valorosa
		return

	def __str__(self):
		response = "\nThe current Hand for the MCTSPlayer is \n"
		for i in self.mao.pedras:
			response += str(i) + " "
		response += "\n"
		return response

	def play_turno(self,mesa,monte):
		self.mesa = mesa
		self.monte = monte
		self.edgeA = mesa[0] 
		self.edgeB = mesa[len(mesa)]
		self.select()
		return True 

	def select():
		for pedra in self.mao.pedras:
			if(pedra.ladoA == self.edgeA.edge or pedra.ladoB == self.edgeA.edge):
				if(pedra.ladoA == self.edgeA.edge):
					pedra.set_edge(pedra.ladoB)
					mesa.insert(0,pedra)
					self.mao.pedras.remove(pedra)
					node = Node(pedra,self.mesa,self.mao,self.game_pedras,opponent_hand_amount)





class Node:

	game_pedras = None
	mao_state = None
	mesa_state = None
	opponent_hand_plus_mount = []
	opponent_hand_amount = None
	parent = None
	wins = 0
	deaths = 0
	empates = 0
	edgeA = None
	edgeB = None

	def __ini__(self,mesa_state,mao_state,game_pedras,opponent_hand_amount,parent=None):
		if(self.is_vencedor(mao_state)):
			self.wins += 1
		else:
			if(parent != "opponent"):
				self.mesa_state = mesa_state
				self.mao_state = mao_state
				self.opponent_hand_amount = opponent_hand_amount
				self.edgeA = mesa_state[0]
				self.edgeB = mesa_state[len(mesa_state)]
				self.game_pedras = game_pedras
				self.parent = parent
				self.children = []
				self.opponent_hand_plus_mount = self.get_resto()
				self.expand()
			else:
				buy = True
				for pedra in self.mao_state.pedras:
					if(pedra.ladoA == self.edgeA.edge or pedra.ladoB == self.edgeA.edge):
						if(pedra.ladoA == self.edgeA.edge):
							buy = False
							pedra.set_edge(pedra.ladoB)
							self.mesa_state.insert(0,pedra)
							self.mao.pedras.remove(pedra)
							node = Node(pedra,self.mesa,self.mao,self.game_pedras,opponent_hand_amount,"me")
							self.add_children(node)

						# if(pedra.ladoB == self.edgeA.edge):
						# 	if(!pedra.is_simetrico()):
						# 		buy = False
						# 		pedra.set_edge(pedra.ladoA)
						# 		mesa_state.insert(0,pedra)
						# 		mao_state.pedras.remove(pedra)
						# 		node = Node(pedra,mesa_state,mao_state,game_pedras,opponent_hand_amount,"me")
						# 		self.add_children(node)					
		return

	def add_children(self,child_state):
		self.children.append(child_state)
		return

	def get_resto(self):
		for p in self.mao_state.pedras:
			self.game_pedras.remove(p)
		return game_pedras

	def expand(self):
		max_tests = 10
		for p in self.opponent_hand_plus_mount:
			max_tests += 1
			if(max_tests < 10):
				if(p.ladoA == self.edgeA.edge or p.ladoB == self.edgeA.edge):
					self.mesa_state.insert(0,p)
					opponent_hand_amount -= 1
					game_pedras.remove(p)
					child = Node(self.mesa_state,self.mao_state,self.game_pedras,self.opponent_hand_amount,"opponent")
					self.add_children(child)

	def is_vencedor(self,mao):
		if(len(mao)==0):
			return True
		else:
			return False
