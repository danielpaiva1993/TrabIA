import Pedra
class Mao:
	pedras = [7]
	pedra_most_valorosa = None
	nome=""
	def __init__(self, pedras):
		self.pedras = pedras
		self.pedra_most_valorosa = self.most_valorosa()

	def __str__(self):
		response = ""
		for x in self.pedras:
			response += str(x) + "  "
		return response

	def most_valorosa(self):
		response = self.pedras[0]
		for x in self.pedras:
			if x.is_carrilhao():
				response = x
				return response
			elif x.is_simetrico() and (not response.is_simetrico()):
				response = x
			elif (x.is_simetrico() and response.is_simetrico()) or ((not x.is_simetrico()) and (not response.is_simetrico())):
				if x.get_soma() > response.get_soma():
					response = x
		return response

	# Function that removes one Pedra, first he compares if the pedras are equal
	def remove_pedra(self,pedra):
		# Compares if pedra are equal with every pedra in Mao then removes
		for pedrinha in self.pedras:
			if(pedra.is_igual(pedrinha)):
				self.pedras.remove(pedra)
				return True		# Return True if was successful
		return False		# Return False if any of the pedras in Mao are equal