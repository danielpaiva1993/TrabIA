class JogadorEMinMax:
	#atributos: mao 
	#metodos buy_pedra, play_turno
