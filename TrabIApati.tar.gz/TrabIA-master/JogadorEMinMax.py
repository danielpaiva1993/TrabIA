import random
import Pedra
import Mao
import Mesa
import Utils as u
class JogadorEMinMax:
	
	mao = []
	cutoff = -999999
	profundidadeMaxi = 9999999999999999999999999

	def __init__(self, mao):
		self.mao = mao
	
	def play_turno(self, mesa, sizeCompra, sizeAdversarioHand):
		jogaveisEsquerda = u.jogaveis_max_esquerda(mesa.atual, self.mao.pedras)
		if mesa.atual[0].esquerda==mesa.atual[-1].direita: ##diminui calculos
			jogaveisDireita = []
		else:
			jogaveisDireita = u.jogaveis_max_direita(mesa.atual, self.mao.pedras)

		if len(jogaveisEsquerda) == 0 and len(jogaveisDireita) == 0:
			
			return mesa.atual

		if len(jogaveisEsquerda) == 0 and len(jogaveisDireita) == 1: ##diminui testes
			print('jogou direto')
			self.mao.pedras.remove(jogaveisDireita[0])
			return u.simula_insert_direita(mesa.atual.copy(), jogaveisDireita[0])

		if len(jogaveisEsquerda) == 1 and len(jogaveisDireita) == 0: #diminui testes
				print('jogou direto')
				self.mao.pedras.remove(jogaveisEsquerda[0])
				return u.simula_insert_esquerda(mesa.atual.copy(), jogaveisEsquerda[0])

		else:
			if (len(jogaveisEsquerda) + len(jogaveisDireita))//2 < len(mesa.atual):
				self.profundidadeMaxi = len(mesa.atual)-(len(jogaveisEsquerda) + len(jogaveisDireita))//2
			else:
				self.profundidadeMaxi = len(mesa.atual)/2
			print(self.profundidadeMaxi)
			novaMesa = mesa.atual
			novaMao = self.mao.pedras.copy()
			valor = -9999999
			for pedra in jogaveisEsquerda:
				mesaTemp = u.simula_insert_esquerda(mesa.atual.copy(), pedra)
				maoTemp = self.mao.pedras.copy()
				maoTemp.remove(pedra)
				novoValor = self.prob_min(mesaTemp, maoTemp, sizeCompra, sizeAdversarioHand, 0, 0)
				if novoValor >= valor:
					valor = novoValor
					novaMesa = mesaTemp
					novaMao = maoTemp
			for pedra in jogaveisDireita:
				mesaTemp = u.simula_insert_direita(mesa.atual.copy(), pedra)
				maoTemp = self.mao.pedras.copy()
				maoTemp.remove(pedra)
				novoValor = self.prob_min(mesaTemp, maoTemp, sizeCompra, sizeAdversarioHand, 0, 0)
				if novoValor >= valor:
					valor = novoValor
					novaMesa = mesaTemp
					novaMao = maoTemp
			self.mao = Mao.Mao(novaMao)
			return novaMesa
	
	def buy_pedra(self, compra):
		purchasedPedra = random.choice(compra)
		self.mao.pedras.append(purchasedPedra)
		compra.remove(purchasedPedra)
		return #purchasedPedra

	def min(self, mesa, mao, sizeCompra, sizeAdversarioHand, turnosSemJogo, profundidade):
		#profundidade+=1
		if profundidade >=self.profundidadeMaxi:
			return sizeAdversarioHand - len(mao)
		valor = 999999999999
		jogaveisEsquerda = u.jogaveis_min_esquerda(mesa, mao)

		if mesa[0].esquerda==mesa[-1].direita: ##diminui calculos
			jogaveisDireita = []
		else:
			jogaveisDireita = u.jogaveis_min_esquerda(mesa, mao)

		for pedra in jogaveisEsquerda:
			mesaTemp = u.simula_insert_esquerda(mesa.copy(), pedra)
			novoValor = self.max(mesaTemp, mao, sizeCompra, sizeAdversarioHand-1, 0, profundidade, valor)
			if novoValor < self.cutoff:
				return novoValor
			if novoValor < valor:
				valor = novoValor
		for pedra in jogaveisDireita:
			mesaTemp = u.simula_insert_direita(mesa.copy(), pedra)
			novoValor = self.max(mesaTemp, mao, sizeCompra, sizeAdversarioHand-1, 0, profundidade, valor)
			if novoValor < self.cutoff:
				return novoValor
			if novoValor < valor:
				valor = novoValor
		return valor

	def max(self, mesa, mao, sizeCompra, sizeAdversarioHand, turnosSemJogo, profundidade, cutoffmin):
		profundidade+=1
		prob = 0
		if profundidade >=self.profundidadeMaxi or len(mao)==0:
			return sizeAdversarioHand - len(mao)
		
		jogaveisEsquerda = u.jogaveis_max_esquerda(mesa, mao)
		if mesa[0].esquerda==mesa[-1].direita: ##diminui calculos
			jogaveisDireita = []
		else:
			jogaveisDireita = u.jogaveis_max_direita(mesa, mao)

		if len(jogaveisEsquerda) != 0 or len(jogaveisDireita) != 0:
			for pedra in jogaveisEsquerda:
				mesaTemp = u.simula_insert_esquerda(mesa.copy(), pedra)
				maoTemp = mao.copy()
				maoTemp.remove(pedra)
				novoValor = self.prob_min(mesaTemp, maoTemp, sizeCompra, sizeAdversarioHand, 0, profundidade)
				if novoValor > cutoffmin:
					return novoValor
				if novoValor > self.cutoff:
					self.cutoff = novoValor
			for pedra in jogaveisDireita:
				mesaTemp = u.simula_insert_direita(mesa.copy(), pedra)
				maoTemp = mao.copy()
				maoTemp.remove(pedra)
				novoValor = self.prob_min(mesaTemp, maoTemp, sizeCompra, sizeAdversarioHand, 0, profundidade)
				if novoValor > cutoffmin:
					return novoValor
				if novoValor > self.cutoff:
					self.cutoff = novoValor
			return self.cutoff
		else: #se max pode jogar, ve qual é mlehor jogada
			if sizeCompra == 0: #se max não pode comprar nem jogar, pula a vez
				turnosSemJogo += 1
				if(turnosSemJogo==2): ##ninguem consegue jogar
					return sizeAdversarioHand - len(mao) 
				else:##max não comprou, então é um turno sem jogo
					return self.prob_min(mesa, mao, sizeCompra, sizeAdversarioHand, turnosSemJogo, profundidade);
			else: #se max não pode jogar, mas pode comprar, vamos tentar calcular a sorte
				
				maoTemp = mao.copy()
				valor = self.worst_compra_max(mesa, mao, sizeCompra, sizeAdversarioHand, turnosSemJogo, profundidade)
				prob = valor
			return prob

	def prob_min(self, mesa, mao, sizeCompra, sizeAdversarioHand, turnosSemJogo, profundidade):
		prob = 0
		#profundidade+=1
		if profundidade >=self.profundidadeMaxi:
			return sizeAdversarioHand - len(mao)
		if sizeAdversarioHand==0:
			return sizeAdversarioHand - len(mao)
		if u.qtd_jogaveis_min(mesa, mao, sizeCompra) == 0:
			if sizeCompra == 0: ## se min não pode jogar nem comprar, pula a vez
				turnosSemJogo += 1
				if(turnosSemJogo==2): ##ninguem consegue jogar ou comprar
					prob = sizeAdversarioHand - len(mao)
				else: ##min não comprou, então é um turno sem jogo
					prob = self.max(mesa, mao, sizeCompra, sizeAdversarioHand, turnosSemJogo, profundidade, 9999999999)
			else: ##se min não pode jogar, mas pode comprar vamos continuar o jogo
				 prob = self.max(mesa, mao, sizeCompra-1, sizeAdversarioHand+1, 0, profundidade, 99999999999) 
		else: ##se é possivel min ter pedra para jogar, vamos tentar calcular a sorte de ele ter ou não

			probPlay = u.prob_min_play(mesa, mao, sizeAdversarioHand)
			prob = probPlay * self.min(mesa, mao, sizeCompra, sizeAdversarioHand, 0, profundidade)
			if probPlay != 1:
				if not sizeCompra:
					prob += (1-probPlay) * self.max(mesa, mao, sizeCompra-1, sizeAdversarioHand+1, 0, profundidade, 99999999999)
				else:
					prob += (1-probPlay) * self.max(mesa, mao, sizeCompra, sizeAdversarioHand, 0, profundidade, 999999999999)
		return prob

	def worst_compra_max(self, mesa, mao, sizeCompra, sizeAdversarioHand, turnosSemJogo, profundidade):
		valor = 999999
		compraveis = u.compraveis(mesa, mao)
		for pedra in compraveis:
			maoTemp = mao.copy()
			maoTemp.append(pedra)
			jogaveisEsquerda = u.jogaveis_max_esquerda(mesa, maoTemp)
			jogaveisDireita = u.jogaveis_max_direita(mesa, maoTemp)
			if len(jogaveisEsquerda) == 0 and len(jogaveisDireita) == 0:
				novoValor = self.prob_min(mesa, maoTemp, sizeCompra-1, sizeAdversarioHand, turnosSemJogo, profundidade)
				if(novoValor<valor):
					valor = novoValor
		return valor
