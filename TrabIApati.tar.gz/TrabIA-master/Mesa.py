import Pedra

class Mesa:
    atual = []

    def __init__(self, firstPedra):
        self.atual = [firstPedra]

    def __str__(self):
        resp = ''
        for p in self.atual:
            resp += str(p)
        return resp + '\n'
        
    def insert_esquerda(self,p):
        if p.direita != self.atual[0].esquerda:
            p.invertePedra()
        self.atual.insert(0, p)
        return

    def insert_direita(self,p):
        if p.esquerda != self.atual[-1].direita:
            p.invertePedra()
        self.atual.append(p)
        return


