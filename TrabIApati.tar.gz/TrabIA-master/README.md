# TrabIA
Trabalho IA
