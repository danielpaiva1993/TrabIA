import Pedra
class Mao:
	pedras = [7]
	
	def __init__(self, pedras):
		self.pedras = pedras

	def __str__(self):
		response = ""
		for x in self.pedras:
			response += str(x) + "  "
		return response

	def most_valorosa(self):
		response = self.pedras[0]
		for x in self.pedras:
			if x.is_carrilhao():
				response = x
				return response
			elif x.is_simetrico() and (not response.is_simetrico()):
				response = x
			elif (x.is_simetrico() and response.is_simetrico()) or ((not x.is_simetrico()) and (not response.is_simetrico())):
				if x.get_soma() > response.get_soma():
					response = x
		return response

	def mao_most_valorosa(self, maoB):## retorna True se self é quem começa
		fakeMao =  Mao([self.most_valorosa(), maoB.most_valorosa()])
		if fakeMao.most_valorosa().is_igual(self.most_valorosa()):
			return True
		return False
