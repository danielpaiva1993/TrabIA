import Pedra
import Mao
import Mesa
import random
import JogadorEMinMax
import Utils as u

class Domino:
	pedras = []
	maoA = []
	jogadorA = None
	maoB = []
	jogadorB = None
	mesa = []
	compra = []

	def __init__(self):
		self.pedras = u.pedras.copy()
		
		self.maoA = Mao.Mao(self.pedras[:7])
		self.jogadorA = JogadorEMinMax.JogadorEMinMax(self.maoA)

		self.maoB = Mao.Mao(self.pedras[7:14])
		self.jogadorB = JogadorEMinMax.JogadorEMinMax(self.maoB) ##TODO apagar
		###self.jogadorB = intB.MonteCarlo(self.maoB)

		self.compra = self.pedras[14:]

		if self.maoA.mao_most_valorosa(self.maoB):
			self.mesa = Mesa.Mesa(self.maoA.most_valorosa())
			self.jogadorA.mao.pedras.remove(self.maoA.most_valorosa())
			print('Jogador EMinMax começou')
			turno = self.turno(self.jogadorB, self.jogadorA, 0)
			if turno == 0:
				print('Empate')
			elif turno == 2:
				print('EMinMax ganhou!')
			else:
				print('MonteCarlo ganhou!')
		else:
			self.mesa = Mesa.Mesa(self.maoB.most_valorosa())
			self.jogadorB.mao.pedras.remove(self.maoB.most_valorosa())
			print('Jogador MonteCarlo começou')
			turno = self.turno(self.jogadorA, self.jogadorB, 0)
			if turno == 0:
				print('Empate')
			elif turno == 1:
				print('EMinMax ganhou!')
			else:
				print('MonteCarlo ganhou!')
		

	def turno(self, jogadorA, jogadorB, turnosSemJogo):
		##1 jogadorA ganhou
		##2 jogadorB ganhou
		##0 empate
			print(self.mesa)
			if(len(jogadorA.mao.pedras) == 0): 
				
				if(len(jogadorB.mao.pedras) == 0): 
					return 0 ##empate
				else:
					return 1 ##A ganhou
			else:
				resp = jogadorA.play_turno(self.mesa, len(self.compra), len(jogadorB.mao.pedras))

				if(resp == self.mesa.atual):
					if(len(self.compra) == 0):
						print('pulou a vez')
						if(turnosSemJogo==1): ##Se B tbm não jogou nem comprou na partida anterior, empate
							return 0
						else:
							turnosSemJogo = 1
					else:
						purchasedPedra = jogadorA.buy_pedra(self.compra)
						turnosSemJogo = 0
				else:
					self.mesa.atual = resp
					turnosSemJogo = 0
					
				proxTurno = self.turno(jogadorB, jogadorA, turnosSemJogo)

				if(proxTurno == 0): ##Empate
					return 0

				if(proxTurno == 1): ##jogadorB ganhou (pois B é "A" em proxTurno)
					return 2

				if(proxTurno == 2): ##jogadorA ganhou (pois A é B em proxTurno)
					return 1
