import Domino as d
d.Domino()